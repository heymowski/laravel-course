#!/bin/bash

# echo 'Initializing entrypoint.sh'
# if [ ! -d "$(pwd)/vendor" ]; then
#     # composer install --no-dev
#     composer install
#     php artisan migrate --force
#     php artisan storage:link
#     npm install
# fi

# chmod -R 777 storage
# chmod -R 777 bootstrap/cache
# echo 'Laravel server is running...'

exec /usr/sbin/apachectl -DFOREGROUND
